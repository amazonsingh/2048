# DSpace Docker Deployment for Aria University

This repository contains Docker configuration for deploying DSpace 8 digital library system with **Supabase PostgreSQL** as the database backend.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        AWS / Cloud Host                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                    Docker Compose                         │  │
│  │                                                           │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐  │  │
│  │  │   DSpace    │  │   DSpace    │  │      Solr       │  │  │
│  │  │  Frontend   │  │  Backend    │  │  Search Engine  │  │  │
│  │  │  (Angular)  │  │(Spring Boot)│  │                 │  │  │
│  │  │  Port:4000  │  │  Port:8080  │  │   Port:8983     │  │  │
│  │  └──────┬──────┘  └──────┬──────┘  └────────┬────────┘  │  │
│  │         │                │                   │           │  │
│  │         └────────────────┼───────────────────┘           │  │
│  │                          │                               │  │
│  └──────────────────────────┼───────────────────────────────┘  │
│                             │                                   │
└─────────────────────────────┼───────────────────────────────────┘
                              │ SSL Connection
                              ▼
              ┌───────────────────────────────┐
              │     Supabase PostgreSQL       │
              │   (External Managed Database) │
              │   db.xxxx.supabase.co:5432    │
              └───────────────────────────────┘
```

## Prerequisites

- Docker 24.0+ and Docker Compose v2
- A Supabase account with a project created
- At least 8GB RAM on the host machine
- 50GB+ available disk space

## Quick Start

### Step 1: Clone and Configure

```bash
# Navigate to the project directory
cd dspace-docker

# Copy environment template
cp .env.example .env

# Edit .env with your Supabase credentials
nano .env  # or use your preferred editor
```

### Step 2: Configure Supabase

1. Go to your [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project (or create a new one)
3. Go to **Project Settings** → **Database**
4. Find your connection details:
   - **Host**: `db.xxxxxxxxxxxx.supabase.co`
   - **Port**: `5432` (direct) or `6543` (pooler)
   - **Database**: `postgres`
   - **User**: `postgres`
   - **Password**: Your database password

5. Update your `.env` file:
```bash
SUPABASE_HOST=db.your-project-ref.supabase.co
SUPABASE_PORT=5432
SUPABASE_DATABASE=postgres
SUPABASE_USER=postgres
SUPABASE_PASSWORD=your-database-password
```

### Step 3: Enable pgcrypto Extension

DSpace requires the `pgcrypto` PostgreSQL extension. Enable it in Supabase:

1. Go to **SQL Editor** in Supabase Dashboard
2. Run:
```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;
```

### Step 4: Build and Start

```bash
# Build the Docker images (this takes 15-30 minutes first time)
docker-compose build

# Start all services
docker-compose up -d

# Watch the logs (Ctrl+C to exit)
docker-compose logs -f
```

### Step 5: Validate Deployment

```bash
# Make the validation script executable
chmod +x scripts/validate.sh

# Run validation
./scripts/validate.sh
```

## Access Points

Once deployed, access your DSpace installation at:

| Service | URL | Description |
|---------|-----|-------------|
| Frontend UI | http://localhost:4000 | Main user interface |
| Backend API | http://localhost:8080/server/api | REST API |
| API Browser | http://localhost:8080/server/api | HAL Browser |
| Solr Admin | http://localhost:8983/solr | Search engine admin |

## Configuration Files

| File | Purpose |
|------|---------|
| `.env` | Environment variables (Supabase credentials, etc.) |
| `config/local.cfg` | DSpace configuration overrides |
| `docker-compose.yml` | Docker service definitions |
| `Dockerfile.backend` | Backend build instructions |
| `Dockerfile.frontend` | Frontend build instructions |

## Common Operations

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f dspace-backend
docker-compose logs -f dspace-frontend
docker-compose logs -f dspace-solr
```

### Restart Services
```bash
# Restart all
docker-compose restart

# Restart specific service
docker-compose restart dspace-backend
```

### Stop Services
```bash
# Stop but keep data
docker-compose stop

# Stop and remove containers (keeps volumes)
docker-compose down

# Stop and remove everything including volumes (DATA LOSS!)
docker-compose down -v
```

### Create Admin User
```bash
docker exec -it dspace-backend /dspace/bin/dspace create-administrator \
  -e admin@aria.edu \
  -f Admin \
  -l User \
  -p YourSecurePassword \
  -c en
```

### Rebuild Search Index
```bash
docker exec -it dspace-backend /dspace/bin/dspace index-discovery -b
```

### Database Operations
```bash
# Check database status
docker exec -it dspace-backend /dspace/bin/dspace database status

# Run migrations
docker exec -it dspace-backend /dspace/bin/dspace database migrate
```

## Troubleshooting

### Backend won't start
```bash
# Check logs for errors
docker logs dspace-backend

# Common issues:
# - Wrong Supabase credentials
# - pgcrypto extension not enabled
# - Solr not ready yet
```

### Database connection failed
```bash
# Test connection from backend container
docker exec -it dspace-backend pg_isready \
  -h db.your-project.supabase.co \
  -p 5432 \
  -U postgres

# Verify SSL mode is correct (Supabase requires SSL)
```

### Solr cores not created
```bash
# Check Solr status
curl http://localhost:8983/solr/admin/cores?action=STATUS

# Manually create cores if needed
docker exec -it dspace-solr solr create_core -c search
docker exec -it dspace-solr solr create_core -c authority
docker exec -it dspace-solr solr create_core -c statistics
docker exec -it dspace-solr solr create_core -c oai
```

### Frontend can't connect to backend
```bash
# Verify backend is healthy
curl http://localhost:8080/server/api

# Check frontend config
docker exec -it dspace-frontend cat /app/dist/browser/assets/config.json
```

## AWS Deployment

For production deployment on AWS:

1. **EC2 Instance**: Use t3.large or larger
2. **Security Groups**: Open ports 80, 443 (load balancer), 22 (SSH admin only)
3. **Load Balancer**: Use ALB with ACM for SSL
4. **Domain**: Configure Route 53 DNS

Update `.env` for production:
```bash
DSPACE_SERVER_URL=https://api.library.aria.edu
DSPACE_UI_URL=https://library.aria.edu
```

## Estimated Costs

| Component | Monthly Cost |
|-----------|--------------|
| Supabase (Free tier) | $0 |
| Supabase (Pro plan) | $25 |
| EC2 t3.large | ~$60 |
| EBS Storage (100GB) | ~$10 |
| Data Transfer | ~$10 |
| **Total** | **~$80-105/month** |

## Support

- DSpace Documentation: https://wiki.lyrasis.org/display/DSDOC/
- DSpace Community: https://dspace.org/
- Supabase Docs: https://supabase.com/docs

## License

DSpace is open source software released under the BSD License.
