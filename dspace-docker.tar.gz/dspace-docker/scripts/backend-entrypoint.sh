#!/bin/bash
# ===========================================
# DSpace Backend Entrypoint Script
# Handles database initialization and startup
# ===========================================

set -e

echo "========================================"
echo "DSpace Backend Starting..."
echo "========================================"

# Wait for Solr to be ready
echo "Waiting for Solr to be ready..."
until curl -sf "http://dspace-solr:8983/solr/admin/cores?action=STATUS" > /dev/null 2>&1; do
    echo "Solr is not ready yet. Waiting..."
    sleep 5
done
echo "Solr is ready!"

# Test database connection
echo "Testing Supabase PostgreSQL connection..."
DB_HOST=$(echo $DSPACE_DB_URL | sed -n 's|.*://\([^:]*\):.*|\1|p')
DB_PORT=$(echo $DSPACE_DB_URL | sed -n 's|.*:\([0-9]*\)/.*|\1|p')

until pg_isready -h "$DB_HOST" -p "$DB_PORT" -U "$DSPACE_DB_USERNAME" > /dev/null 2>&1; do
    echo "PostgreSQL is not ready yet. Waiting..."
    sleep 5
done
echo "PostgreSQL connection successful!"

# Check if pgcrypto extension exists
echo "Verifying pgcrypto extension..."
PGPASSWORD="$DSPACE_DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DSPACE_DB_USERNAME" -d "${SUPABASE_DATABASE:-postgres}" -c "CREATE EXTENSION IF NOT EXISTS pgcrypto;" 2>/dev/null || echo "Note: pgcrypto may already exist or require superuser privileges"

# Initialize database if needed
if [ ! -f /dspace/.db_initialized ]; then
    echo "Initializing DSpace database schema..."
    /dspace/bin/dspace database migrate
    
    # Create administrator account if credentials provided
    if [ -n "$DSPACE_ADMIN_EMAIL" ] && [ -n "$DSPACE_ADMIN_PASSWORD" ]; then
        echo "Creating administrator account..."
        /dspace/bin/dspace create-administrator -e "$DSPACE_ADMIN_EMAIL" -f "$DSPACE_ADMIN_FIRSTNAME" -l "$DSPACE_ADMIN_LASTNAME" -p "$DSPACE_ADMIN_PASSWORD" -c en || true
    fi
    
    touch /dspace/.db_initialized
    echo "Database initialization complete!"
else
    echo "Database already initialized. Running migrations..."
    /dspace/bin/dspace database migrate || true
fi

# Update Discovery index
echo "Updating Solr search index..."
/dspace/bin/dspace index-discovery -b || true

echo "========================================"
echo "DSpace Backend Ready!"
echo "API available at: http://localhost:8080/server/api"
echo "========================================"

# Execute the main command
exec "$@"
