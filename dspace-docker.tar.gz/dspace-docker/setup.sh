#!/bin/bash
# ===========================================
# DSpace Docker Quick Setup Script
# Automates initial deployment steps
# ===========================================

set -e

echo "========================================"
echo "DSpace Docker Quick Setup"
echo "========================================"
echo ""

# Check for Docker
if ! command -v docker &> /dev/null; then
    echo "Error: Docker is not installed."
    echo "Please install Docker first: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check for Docker Compose
if ! (command -v docker-compose &> /dev/null || docker compose version &> /dev/null 2>&1); then
    echo "Error: Docker Compose is not available."
    exit 1
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "Creating .env file from template..."
    cp .env.example .env
    
    echo ""
    echo "IMPORTANT: You need to configure your Supabase credentials!"
    echo ""
    echo "Please edit .env and set these values:"
    echo "  - SUPABASE_HOST"
    echo "  - SUPABASE_PASSWORD"
    echo ""
    echo "Then run this script again."
    echo ""
    
    # Open editor if available
    if command -v nano &> /dev/null; then
        read -p "Would you like to edit .env now? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            nano .env
        fi
    fi
fi

# Source .env
source .env

# Validate required variables
if [ -z "$SUPABASE_HOST" ] || [ "$SUPABASE_HOST" = "db.your-project-ref.supabase.co" ]; then
    echo "Error: SUPABASE_HOST is not configured in .env"
    exit 1
fi

if [ -z "$SUPABASE_PASSWORD" ] || [ "$SUPABASE_PASSWORD" = "your-supabase-password" ]; then
    echo "Error: SUPABASE_PASSWORD is not configured in .env"
    exit 1
fi

echo "Configuration validated!"
echo ""

# Test Supabase connection
echo "Testing Supabase connection..."
if command -v pg_isready &> /dev/null; then
    if pg_isready -h "$SUPABASE_HOST" -p "${SUPABASE_PORT:-5432}" -U "${SUPABASE_USER:-postgres}" > /dev/null 2>&1; then
        echo "✓ Supabase connection successful!"
    else
        echo "⚠ Warning: Could not connect to Supabase."
        echo "  Please verify your credentials and that the database is accessible."
        read -p "Continue anyway? (y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
else
    echo "Note: pg_isready not available, skipping connection test."
fi

echo ""

# Build images
echo "Building Docker images..."
echo "This may take 15-30 minutes on first run..."
echo ""

docker-compose build

echo ""
echo "Build complete!"
echo ""

# Start services
read -p "Start DSpace services now? (y/n) " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Starting services..."
    docker-compose up -d
    
    echo ""
    echo "Services starting! This may take 2-5 minutes for all services to be ready."
    echo ""
    echo "You can monitor the startup progress with:"
    echo "  docker-compose logs -f"
    echo ""
    echo "Once ready, access DSpace at:"
    echo "  - Frontend: http://localhost:4000"
    echo "  - Backend API: http://localhost:8080/server/api"
    echo ""
    echo "Run the validation script to check everything is working:"
    echo "  ./scripts/validate.sh"
else
    echo "To start services later, run:"
    echo "  docker-compose up -d"
fi

echo ""
echo "Setup complete!"
