# DSpace Solr Configuration

This directory should contain the DSpace Solr configset files.

## Setup Instructions

The DSpace Solr configsets are included in the DSpace source code. During the Docker build process, these are automatically extracted. However, if you need to manually set up the configsets:

1. Download DSpace source:
   ```bash
   git clone https://github.com/DSpace/DSpace.git
   cd DSpace
   ```

2. Copy the Solr configsets:
   ```bash
   cp -r dspace/solr/* /path/to/this/directory/
   ```

## Required Cores

DSpace requires the following Solr cores:
- `search` - Main search index
- `authority` - Authority control
- `statistics` - Usage statistics
- `oai` - OAI-PMH harvesting

## Configuration Files

Each core requires these configuration files:
- `solrconfig.xml` - Solr configuration
- `schema.xml` - Field definitions
- `synonyms.txt` - Search synonyms
- `stopwords.txt` - Words to ignore in search

## Note

The Docker Compose configuration will automatically create these cores on startup.
If you encounter issues, check that the configset files are properly mounted.
